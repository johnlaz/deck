Deck 0.9.0 — on-screen deck widget for Windows (single exe, no installer)

RUN
  Double-click deck.exe. A tray icon appears and a small dashboard window opens.
  Tray icon: left-click = open dashboard; right-click = menu
    - Always on top            (default on)
    - Don't steal focus        (default on; keeps Outlook/Spotify focused while you click the widget)
    - Start with Windows       (adds a Run entry, starts quietly in the tray)
    - Reload layout and config
    - Open config folder
    - Quit Deck
  Closing the dashboard window only closes the window; LazDeck keeps running in the tray.

VIEW
  Gear menu > Slim bar shrinks the window to a thin strip; Focus restores it to normal size.
  Gear menu > Compact mode slims the header and gaps (remembered). The < button in the header goes
  back to Home from any page, so Home keys on sub-pages are optional.

EDIT KEYS
  In edit mode, drag any key onto another to swap them (links and overrides follow).
  Dashboard gear button > Edit keys. Pick a page from the drop-down, click any key (or an empty one)
  to set its label, icon and action: website, app/file/folder, hotkey, text template, jump to a page,
  timer, mic mute. Icons: auto-made from the label, your own image, or a built-in one. Done leaves edit mode.
  Before each save the previous layout is kept as layout.json.prev in the config folder.

SETTINGS SCREEN (0.7.0)
  Gear menu > Settings... covers:
    - Browser: which browser runs the Deck window and opens website keys (Auto, Chrome, Edge, or a path to
      another browser). Website keys switch at once; the Deck window changes the next time it opens.
    - Window: always on top, don't steal focus, open on start, start with Windows.
    - Auto-switch rules (a collapsed section): change the window-title pattern that brings up an app page. Empty = built-in rule.
    - Home Assistant: address, access token and keys (for example ha:5 = light.office). The token is
      write-only: it is never shown or exported, and one tick clears it.
    - Variables: name = value lines (for example odoo = https://yours.odoo.com).
    - Key overrides: any key replaced in config.json is listed; tick one to put the built-in key back.
  Bad input (an invalid pattern, a browser that isn't installed, a malformed address) is rejected with a
  message and nothing is changed.

PHONE / TABLET DASHBOARD (0.8.0)
  Gear menu > Settings... > Phone / tablet dashboard. Tick Enable, scan the QR code with the phone (same Wi-Fi) and
  the deck appears on it, following whichever app is in front on the PC. Keys run on the PC.
  - Portrait/landscape: the A button in the phone page header cycles Auto / Portrait / Landscape; the arrows button goes full screen.
  - Vibrate on key press (0.9.0): on by default for the phone only (Android Chrome; iPhones ignore it). Switch it off in the same section.
  - First time Windows asks to allow Deck through the firewall: allow it on Private networks.
  - "New pairing code" signs out every paired phone. The phone page can press keys only; it cannot edit anything.
  - To keep an old phone's screen on, use Android's "Stay awake" developer option, or a kiosk browser such as Fully Kiosk.

BACKUP, RESTORE AND PAGE PACKS (0.9.0)
  Gear menu > Settings... > Backup & restore.
  - Automatic backup once a day when something changed (last 10 kept) in %APPDATA%\LazDeck\backups.
  - Back up now makes a manual backup that is never deleted automatically.
  - The list has Restore and Delete. Anything that replaces your setup writes a "before a change" backup first.
  - Export pages: tick pages; pages they link to and the templates they use come along (one lazdeck-pages.json).
  - Import pages: shows a preview, then add as a copy, replace, or skip pages that already exist. Keys that open
    programs are counted and warned about.
  - Not included in a page pack: key overrides, Home Assistant settings, variables, auto-switch rule overrides.

EXPORT / IMPORT SETTINGS (0.3.0)
  Dashboard gear button > Export settings saves layout, icons, templates and config to one
  lazdeck-settings.json (Home Assistant token is left out). Import settings loads one back;
  your current files are saved first to a backup-YYYYMMDD-HHMMSS folder in the config folder.

CONFIG  (folder: %APPDATA%\LazDeck)
  config.json    port (default 8788), vars.odoo (your Odoo base URL), Home Assistant url/token/entities,
                 and "overrides" to set any key without touching the layout, e.g.
                   "overrides": { "odoo:3": { "kind": "url", "url": "https://YOURS.odoo.com/..." } }
                 Key ids are "<page>:<key number>" (see layout list in LAYOUT.md from the icon pack).
  snippets.json  your email/prompt text. Empty snippets do nothing until filled.
  layout.json    optional: copy one in to replace the built-in layout entirely.
  lazdeck.log    last-run log.
  Yellow dot on a key = not set up yet; pressing it tells you what's missing.

APP PAGES (auto-switch)
  A web-app page can match by address as well as by window title; an address match wins over a title match,
  so a page for one site is not taken over by a broader browser rule.
  Outlook (inbox/main window) .... olk.exe or OUTLOOK.EXE, any window
  Outlook Compose ................. a new-email/reply window (matched by window title)
    -> Send, Save, Discard, Link, Bold, Italic, Undo + your top 5 templates, "More Templates" opens a
       templates page with room for more. "Back" returns to the compose page.
  Spotify ......................... Spotify.exe
  Browser Tools ................... Edge or Chrome: tabs, find, bookmark, zoom, DevTools
  PowerPoint, VS Code, Teams, Zoom, File Explorer, Windows Terminal, VLC: each gets a tool page of
    its most-used shortcuts when it is in front (Explorer's page ignores the bare desktop).
  Edit any of these pages with Edit keys; shortcuts are plain hotkey keys.
  Pages disappear when you leave the app. Home key = launcher until you switch apps.

TEMPLATES (snippets.json)
  Paste happens into the email you are writing (compose page only).
  - Plain text: just write the text.
  - Formatted: start the value with an HTML tag, e.g.
      "credit50": "<p>Hi,</p><p>We've applied a <b>50% credit</b> to your account.</p><p>Thanks,<br>John</p>"
    Bold, links and lists paste with their formatting into the new Outlook.
  The new Outlook does not support .oft template files, so snippets are the template system.

IF THE COMPOSE PAGE DOESN'T APPEAR WHEN YOU OPEN A NEW EMAIL
  1. Open a new email, then open lazdeck.log (tray > Open config folder).
  2. Find the line: focus: exe=olk.exe title="..." -> page=...   for the compose window.
  3. Put a regex matching that title in config.json:
       "matchTitles": { "outlook_compose": "(?i)^new message" }
     then tray > Reload layout and config. (Or send me the log line and I'll set the default.)

NOT CONFLICTING WITH LMC REMOTE
  Port 8788 (LMC uses 8765), own instance lock, own config folder, own startup entry,
  registers no global hotkeys. Both can run at once.

SECURITY
  Listens on 127.0.0.1 only; session token + Host/Origin checks so web pages can't trigger keys.

KEYBOARD SHORTCUTS INSIDE WEB APPS
  Deck sends keys as virtual-key codes only. If you wire a key to a web page you wrote yourself, read
  event.keyCode in its keydown handler; event.code is empty for these keys in Chrome.

KNOWN LIMITS (v0.1)
  - New Outlook window titles and shortcuts are best guesses (see compose-page note above); all keys are
    overridable in config.json -> overrides.
  - Mic mute uses a PowerShell/Core Audio call; verify on your mic.
  - Unsigned exe: SmartScreen/antivirus may warn because it sends keystrokes.
  - Dashboard uses Edge (or Chrome) in app mode, so Edge helper processes exist only while the window is open.

CONTACT: lazlab.io@gmail.com
